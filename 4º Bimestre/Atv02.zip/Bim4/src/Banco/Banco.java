package Banco;

public class Banco {
	 public static class Conta {
		 	// Atributos:
	        private int id;
	        private String titular;
	        private double saldo;

	        // Construtor para inicializar o id, o titular e o saldo inicial.
	        public Conta(int id, String titular, double saldoInicial) {
	            this.id = id;
	            this.titular = titular;
	            this.saldo = saldoInicial;
	        }

	        // Depositar(double valor): Adiciona o valor ao saldo.
	        public void depositar(double valor) {
	            if (valor > 0) {
	                saldo += valor;
	                System.out.println("Depósito de R$ " + valor + " realizado na conta: " + id);
	            } else {
	                System.out.println("Valor de depósito inválido.");
	            }
	        }

	        // Método para sacar
	        public void sacar(double valor) {
	            if (valor <= saldo) {
	                saldo -= valor;
	                System.out.println("Saque de R$ " + valor + " realizado na conta: " + id);
	            } else {
	                System.out.println("Saldo insuficiente na conta: " + id);
	            }
	        }

	        // exibirDetalhes(): Exibe os detalhes da conta (id, titular e saldo).
	        public void exibirDetalhes() {
	            System.out.println("ID da Conta: " + id);
	            System.out.println("Titular: " + titular);
	            System.out.println("Saldo: R$ " + saldo);
	            System.out.println("-----------------------------------");
	        }
	    }

	    // Testando as contas
	    public static void main(String[] args) {
	        Conta conta_01 = new Conta(01, "Nicole", 0.0);
	        Conta conta_02 = new Conta(02, "João", 0.0);
	        Conta conta_03 = new Conta(03, "Patricia", 0.0);

	        // Depositos
	        conta_01.depositar(200.00);
	        conta_02.depositar(100.00);
	        
	        // Saques
	        conta_02.sacar(50.00);   
	        conta_03.sacar(800.00);     

	        System.out.println("Detalhes das contas após as operações:");
	        conta_01.exibirDetalhes();
	        conta_02.exibirDetalhes();
	        conta_03.exibirDetalhes();
	    }

}

