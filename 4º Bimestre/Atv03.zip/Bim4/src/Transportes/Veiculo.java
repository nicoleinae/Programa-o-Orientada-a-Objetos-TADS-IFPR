package Transportes;

public interface Veiculo {
	void mover();
}
